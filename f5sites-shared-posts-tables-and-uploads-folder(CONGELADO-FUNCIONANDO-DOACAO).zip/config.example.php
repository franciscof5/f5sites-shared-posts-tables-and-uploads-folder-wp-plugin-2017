<?php
#$config = array("asd");
#
$config["posts"] = "wp2_posts";
$config["postmeta"] ="wp2_postmeta";
#
$config["terms"] ="wp2_terms";
$config["term_taxonomy"] ="wp2_term_taxonomy";
$config["term_relationships"] ="wp2_term_relationships";
$config["termmeta"] ="wp2_termmeta";
$config["taxonomy"] ="wp2_taxonomy";
#
$config["comments"] ="wp3_comments";
$config["commentmeta"] ="wp3_commentmeta";
#
$config["links"] ="wp4_fnetwork_links";

?>
Doação Pomodoros 2017
O Pomodoros nasceu com um objetivo, fornecer um serviço gratuito para pessoas e empresas melhorarem a gestão do tempo. Após ajudar muitas pessoas sem cobrar nada por isso, por 7 anos o projeto foi mantido no ar pelo bolso do seu próprio criador, porém muitas vezes o sistema caia e não atingia estabilidade, por causa de alto custo de manutenção.

A partir de 2017 mudamos, vamos continuar gratuito para todos e mais, nosso código-fonte está aberto, portanto pedimos aos usuários mais afortunados, colabore com o projeto e suporte outros usuários, que não tem condição de pagar pelo serviço.