<?php
#$config = array("asd");
#
$config["posts"] = "1fnetwork_posts";
$config["postmeta"] ="1fnetwork_postmeta";
#
$config["terms"] ="1fnetwork_terms";
$config["term_taxonomy"] ="1fnetwork_term_taxonomy";
$config["term_relationships"] ="1fnetwork_term_relationships";
$config["termmeta"] ="1fnetwork_termmeta";
$config["taxonomy"] ="1fnetwork_taxonomy";
#
$config["comments"] ="3fnetwork_comments";
$config["commentmeta"] ="3fnetwork_commentmeta";
#
$config["links"] ="4fnetwork_links";

?>

