=== F5 Sites | Shared Posts Tables & Uploads Folder ===
Contributors: f5sites, franciscof5
Tags: post_type, data management, sync, woocommerce, wpmu, database 
Requires at least: 3.2
Tested up to: 4.7.2
Stable tag: 1.0
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html
Donate link: http://www.f5sites.com/donate/

Hacks WordPress databases, sharing posts and taxonomies tables for multiple wp install under the same database, by default wp only can share tables users and usermeta. Made for use in fnetwork.",
	"type": "wordpress-plugin

== Description ==

Hacks WordPress databases, sharing posts and taxonomies tables for multiple wp install under the same database, by default wp only can share tables users and usermeta. Made for use in fnetwork.",
	"type": "wordpress-plugin

It is for advanced users and optimized for WordPress as composer package. Just create a wordpress category with the current site domain, like www.f5sites.com or www.franciscomat.com and it will only be displayed in the correct location Original project for use in f5sites fnetwork. 

[F5 Sites | WordPress Dev](https://www.f5sites.com/software/wordpress/)

[F5 Sites | Shared Posts Tables & Uploads Folder](https://www.f5sites.com/software/wordpress/f5sites-shared-posts-tables-and-uploads-folder/)

== Installation ==

= From your WordPress dashboard =

1. Visit 'Plugins > Add New'
2. Search for 'F5 Sites | Shared Posts Tables & Uploads Folder'
3. Activate it from your Plugins page.

== ChangeLog ==

= 1.0 =
* Initial release